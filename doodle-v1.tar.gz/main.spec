# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['examples\\breakout\\main.py'],
    pathex=[],
    binaries=[('C:\\Users\\Ashish\\my code\\Doodle\\doodle\\_doodle.pyd', 'doodle')],
    datas=[('C:\\Users\\Ashish\\my code\\Doodle\\examples\\breakout\\layout.html', '.'), ('C:\\Users\\Ashish\\my code\\Doodle\\examples\\breakout\\styles.css', '.'), ('C:\\Users\\Ashish\\my code\\Doodle\\examples\\breakout\\shaders', 'shaders')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='main',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
